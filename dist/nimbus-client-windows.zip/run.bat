@echo off
cd /d "%~dp0"
nimbus-client.exe -config config.json
echo.
echo Client exited. Press any key to close.
pause >nul