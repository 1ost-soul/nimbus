Nimbus client (Windows) - quick start

1. Edit config.json:
   - server_addr       : TCP / QUIC server domain and port (domain recommended)
   - webtransport_addr : optional WebTransport UDP domain and port; leave empty to reuse server_addr
   - sni               : same server domain
   - psk               : same 32-byte base64 key as the server
   - ca_pem_file       : your CA certificate file name (place it in this folder)
   - transport         : tcp / quic / webtransport / auto (default auto: TCP -> QUIC -> WebTransport)
   - prefer_family     : ipv4 / ipv6 / auto (default ipv4)

   QUIC and WebTransport use the included BBR congestion controller. For best
   throughput on networks that allow UDP, set transport to "quic" or
   "webtransport". Keep "auto" if you want TCP fallback.

2. Double-click run.bat and keep the window open.
   Running nimbus-client.exe directly may flash and exit; use run.bat instead.

3. Verify (do not rely on any other local proxy):
   curl -x http://127.0.0.1:34133 https://example.com
   curl --socks5-hostname 127.0.0.1:34133 https://example.com
   Both should return CODE=200.

Never commit real credentials, certificates, or logs.

License: MIT. See LICENSE.txt. Vendored third-party code keeps its own
license; see THIRD_PARTY_NOTICES.txt.
