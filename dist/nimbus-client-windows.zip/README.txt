Nimbus client (Windows) - quick start

1. Edit config.json:
   - server_addr  : your server domain and port (domain recommended)
   - sni          : same domain
   - psk          : same 32-byte base64 key as the server
   - ca_pem_file  : your CA certificate file name (place it in this folder)
   - transport    : tcp / quic / auto (default auto)
   - prefer_family: ipv4 / ipv6 / auto (default ipv4)

2. Double-click run.bat and keep the window open.
   Running nimbus-client.exe directly may flash and exit; use run.bat instead.

3. Verify (do not rely on any other local proxy):
   curl -x http://127.0.0.1:34133 https://example.com
   curl --socks5-hostname 127.0.0.1:34133 https://example.com
   Both should return CODE=200.

Never commit real credentials, certificates, or logs.