﻿Nimbus client (Windows) - quick start

1. Edit config.json:
   - server_addr       : server domain and port (direct mode) or CDN domain:443 (CDN mode)
   - webtransport_addr : optional WebTransport UDP domain and port; leave empty to reuse server_addr
   - sni               : same server/CDN domain
   - psk               : same 32-byte base64 key as the server
   - ca_pem_file       : CA certificate file for direct mode pinning (place it in this folder)
   - transport         : tcp / quic / webtransport / auto (default auto)
   - prefer_family     : ipv4 / ipv6 / auto (default ipv4)
   - connection_mode   : auto / direct_tcp / direct_quic / direct_webtransport / cdn
   - cdn_auto_select   : true to probe CDN ingress candidates at startup (default true)
   - cdn_candidate_ips : optional CDN edge IP list; leave empty to use built-in candidates
   - cdn_ca_pem_file   : optional CA for CDN edge cert; leave empty to use system roots

   CDN mode uses wss://<sni>/api/events/<psk-derived-hash> over TCP/WebSocket.
   Free CDN tiers do not support QUIC/WebTransport UDP; CDN and QUIC/WT are mutually exclusive.
   Do not use ca_pem_file (origin pinning) as cdn_ca_pem_file unless you know the edge cert chain.

2. Double-click run.bat and keep the window open.
   Running nimbus-client.exe directly may flash and exit; use run.bat instead.

3. Verify (do not rely on any other local proxy):
   curl -x http://127.0.0.1:34133 https://example.com
   curl --socks5-hostname 127.0.0.1:34133 https://example.com
   Both should return HTTP 200.

Never commit real credentials, certificates, or logs.

License: MIT. See LICENSE.txt. Vendored third-party code keeps its own
license; see THIRD_PARTY_NOTICES.txt.
